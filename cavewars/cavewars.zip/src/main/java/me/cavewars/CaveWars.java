package me.cavewars;
import org.bukkit.plugin.java.JavaPlugin;
public class CaveWars extends JavaPlugin {
    @Override public void onEnable() { getLogger().info("CaveWars enabled"); }
    @Override public void onDisable() { }
}
